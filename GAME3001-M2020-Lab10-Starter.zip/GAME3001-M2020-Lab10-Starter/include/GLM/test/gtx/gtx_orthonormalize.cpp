#include <glm/gtx/orthonormalize.hpp>

int main()
{
	int Error(0);

	return Error;
}
